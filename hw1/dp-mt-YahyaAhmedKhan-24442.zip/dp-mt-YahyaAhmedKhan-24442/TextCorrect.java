public class TextCorrect {
    String stringToCorrect;

}