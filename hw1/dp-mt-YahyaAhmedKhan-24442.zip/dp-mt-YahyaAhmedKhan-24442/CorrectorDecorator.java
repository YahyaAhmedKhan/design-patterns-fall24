public abstract class CorrectorDecorator extends TextCorrect {

    abstract String correctionFunc();

}
