public class AutoCorrectChecker extends CorrectorDecorator {

    TextCorrect textToCorrect;

    AutoCorrectChecker(TextCorrect t) {
        textToCorrect = t;
    }

    @Override
    String correctionFunc() {

        String s = this.textToCorrect.stringToCorrect;
        this.textToCorrect.stringToCorrect = s.replaceFirst("recieve", "receive");
        return this.textToCorrect.stringToCorrect;
    }

}
