public class Client {
    public static void main(String[] args) {

        TextCorrect t = new TextCorrect();
        t.stringToCorrect = "I is trying to recieve teh results";

        // CorrectorDecorator decoratedTextCorrect =
        CorrectorDecorator ct = new SpellChecker(t);
        ct = new GrammarChecker(ct);
        ct = new AutoCorrectChecker(ct);

        System.out.println(t.stringToCorrect);
        System.err.println(ct.stringToCorrect);

    }
}
