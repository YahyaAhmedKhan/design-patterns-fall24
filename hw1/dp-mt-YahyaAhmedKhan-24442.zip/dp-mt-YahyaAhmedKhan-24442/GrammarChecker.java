public class GrammarChecker extends CorrectorDecorator {
    TextCorrect textToCorrect;

    GrammarChecker(TextCorrect t) {
        textToCorrect = t;
    }

    String correctionFunc() {

        String s = this.textToCorrect.stringToCorrect;
        this.textToCorrect.stringToCorrect = s.replaceFirst("I is", "I am");
        return this.textToCorrect.stringToCorrect;
    }
}
