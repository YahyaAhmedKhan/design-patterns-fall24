public class SpellChecker extends CorrectorDecorator {
    TextCorrect textToCorrect;

    SpellChecker(TextCorrect t) {
        textToCorrect = t;
    }

    String correctionFunc() {
        String s = this.textToCorrect.stringToCorrect;
        this.textToCorrect.stringToCorrect = s.replaceFirst("teh", "the");
        return this.textToCorrect.stringToCorrect;
    }

}